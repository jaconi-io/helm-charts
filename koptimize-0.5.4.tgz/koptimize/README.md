# koptimize

Helm chart for [koptimize](https://github.com/jaconi-io/koptimize). Note, that
while the Helm chart is open source and the Docker image is public, the code for
koptimize itself is private.

koptimize aims at reducing cost of a Kubernetes cluster, going further than, for
example, the cluster autoscaler.

## Features

- A mutating webhook, that forces workloads (that tolerate spot instances) onto
  spot instances. This is helpful, to ramp up spot instance usage. Example:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
  namespace: default
spec:
  ...
  tolerations:
    - key: cloud.google.com/gke-spot
      operator: Equal
      value: "true"
      effect: NoSchedule
```

becomes

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-pod
  namespace: default
spec:
  ...
  affinity:
    nodeAffinity:
      requiredDuringSchedulingIgnoredDuringExecution:
        nodeSelectorTerms:
          - matchExpressions:
              - key: cloud.google.com/gke-spot
                operator: In
                values:
                  - "true"
  tolerations:
    - key: cloud.google.com/gke-spot
      operator: Equal
      value: "true"
      effect: NoSchedule
```

## Parameters

### Common parameters

| Name               | Description                         | Value |
| ------------------ | ----------------------------------- | ----- |
| `imagePullSecrets` | The image pull secrets to use.      | `[]`  |
| `nameOverride`     | Override for the chart name.        | `""`  |
| `fullnameOverride` | Override for the chart's full name. | `""`  |

### Deployment parameters

| Name                 | Description                                      | Value                     |
| -------------------- | ------------------------------------------------ | ------------------------- |
| `replicaCount`       | Number of replicas for the koptimize deployment. | `1`                       |
| `priorityClassName`  | Priority Class for the koptimize deployment.     | `system-cluster-critical` |
| `annotations`        | Annotations to add to the deployment             | `{}`                      |
| `podAnnotations`     | The annotations to add to the pod.               | `{}`                      |
| `podSecurityContext` | The pod's security context.                      | `{}`                      |
| `nodeSelector`       | The nodeSelector to use.                         | `{}`                      |
| `tolerations`        | The tolerations.                                 | `[]`                      |
| `affinity`           | The affinity settings.                           | `{}`                      |

### Controller parameters

| Name                          | Description                                | Value                         |
| ----------------------------- | ------------------------------------------ | ----------------------------- |
| `controller.image.repository` | The controller image.                      | `ghcr.io/jaconi-io/koptimize` |
| `controller.image.pullPolicy` | The controller image's pull policy.        | `IfNotPresent`                |
| `controller.image.tag`        | The controller image tag.                  | `""`                          |
| `controller.securityContext`  | The controller container security context. | `{}`                          |
| `controller.resources`        | The controller container resources.        | `{}`                          |

### Scheduler parameters

| Name                         | Description                               | Value                         |
| ---------------------------- | ----------------------------------------- | ----------------------------- |
| `scheduler.enabled`          | Enable the scheduler container.           | `false`                       |
| `scheduler.image.repository` | The scheduler image.                      | `ghcr.io/jaconi-io/koptimize` |
| `scheduler.image.pullPolicy` | The scheduler image's pull policy.        | `IfNotPresent`                |
| `scheduler.image.tag`        | The scheduler image tag.                  | `""`                          |
| `scheduler.securityContext`  | The scheduler container security context. | `{}`                          |
| `scheduler.resources`        | The scheduler container resources.        | `{}`                          |

### Service Account parameters

| Name                         | Description                                           | Value  |
| ---------------------------- | ----------------------------------------------------- | ------ |
| `serviceAccount.create`      | Specifies whether a service account should be created | `true` |
| `serviceAccount.annotations` | Annotations to add to the service account             | `{}`   |
| `serviceAccount.name`        | The name of the service account to use.               | `""`   |

### Service parameters

| Name                  | Description                       | Value       |
| --------------------- | --------------------------------- | ----------- |
| `service.type`        | The service type                  | `ClusterIP` |
| `service.port`        | The service port                  | `443`       |
| `service.targetPort`  | The service target port           | `9443`      |
| `service.annotations` | Annotations to add to the service | `{}`        |

### Autoscaling parameters

| Name                                         | Description                       | Value   |
| -------------------------------------------- | --------------------------------- | ------- |
| `autoscaling.enabled`                        | Enabled autoscaling               | `false` |
| `autoscaling.minReplicas`                    | Min number of replicas            | `1`     |
| `autoscaling.maxReplicas`                    | Max number of replicas            | `100`   |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization percentage | `80`    |

### Pod Disruption Budget

| Name                  | Description                      | Value |
| --------------------- | -------------------------------- | ----- |
| `podDisruptionBudget` | Pod Disruption Budget parameters | `{}`  |

### Service Monitor parameters

| Name                           | Description                                    | Value   |
| ------------------------------ | ---------------------------------------------- | ------- |
| `serviceMonitor.create`        | Enable or disable the Service Monitor creation | `false` |
| `serviceMonitor.interval`      | Scrape interval                                | `10s`   |
| `serviceMonitor.scrapeTimeout` | Scrape timeout                                 | `10s`   |

**This section is generated using metadata from [values.yaml](values.yaml)!**
