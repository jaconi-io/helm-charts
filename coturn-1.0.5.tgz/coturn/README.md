# coturn

Helm chart for [coturn](https://github.com/coturn/coturn) TURN and STUN server.

## Testing

Install the coturn Helm chart with `--allow-loopback-peers` and `--no-auth`.

Emulate a peer by running `turnutils_peer`:

```shell
turnutils_peer -L 127.0.0.1
```

Port forward coturn:

```shell
kubectl port-forward --namespace coturn services/coturn 3478:3478
```

Emulate a client by running `turnutils_uclient`:

```shell
turnutils_uclient -t -e 127.0.0.1 -X 127.0.0.1
```

## Parameters

### coturn Parameters

The parameters in this section map to coturn server command line flags. For
example: `fingerprint: true` is equivalent to `--fingerprint`. Any options
that are not exposed by the chart directly, can be set using `extraOptions`.

| Name                         | Description                                               | Value         |
| ---------------------------- | --------------------------------------------------------- | ------------- |
| `fingerprint`                | Use fingerprints in the TURN messages.                    | `false`       |
| `lt-cred-mech`               | Use long-term credential mechanism.                       | `false`       |
| `realm`                      | The default realm to be used for users.                   | `example.com` |
| `cert`                       | Certificate file in PEM format.                           | `nil`         |
| `pkey`                       | Private key file in PEM format.                           | `nil`         |
| `extraOptions`               | Additional command line flags (for example, `--verbose`). | `[]`          |
| `users`                      | Users for the long-term credential mechanism.             | `[]`          |
| `users[0].name`              | Username for the long-term credential mechanism.          |               |
| `users[0].secretKeyRef.name` | Name of the secret with the users password.               |               |
| `users[0].secretKeyRef.key`  | Name of the key with the users password.                  |               |

### cert-manager Parameters

When using [cert-manager](https://cert-manager.io), a
[Certificate](https://cert-manager.io/docs/usage/certificate/) resource can
be created by this chart:

```yaml
certificate:
  enabled: true
  dnsName: coturn.example.com
  issuerName: letsencrypt
```

The resulting TLS certificate and private key will be passed to coturn via
the `--cert` and `--pkey` flags. The settings `cert` and `pkey` will be
ignored.

| Name                     | Description | Value                |
| ------------------------ | ----------- | -------------------- |
| `certificate.enabled`    |             | `false`              |
| `certificate.dnsName`    |             | `coturn.example.com` |
| `certificate.issuerName` |             | `letsencrypt`        |

### Traefik Parameters

When using [Traefik](https://traefik.io), a
[IngressRouteTCP](https://doc.traefik.io/traefik/routing/providers/kubernetes-crd/#kind-ingressroutetcp)
and a
[IngressRouteUDP](https://doc.traefik.io/traefik/routing/providers/kubernetes-crd/#kind-ingressrouteudp)
resource can be created by this chart:

```yaml
traefik:
  enabled: true
  entryPoints:
    tcp: tcp
    tcp-tls: tcp-tls
    udp: udp
    udp-tls: udp-tls
```

When using the official Traefik Helm chart, the following (or similar)
configuration is needed for Traefik:

```yaml
ports:
  tcp:
    port: 3478
    nodePort: 30478
    expose: true
    exposedPort: 3478
    protocol: TCP
  tcp-tls:
    port: 5349
    nodePort: 30349
    expose: true
    exposedPort: 5349
    protocol: TCP
  udp:
    port: 3478
    nodePort: 30478
    expose: true
    exposedPort: 3478
    protocol: UDP
  udp-tls:
    port: 5349
    nodePort: 30349
    expose: true
    exposedPort: 5349
    protocol: UDP
```

| Name                          | Description | Value     |
| ----------------------------- | ----------- | --------- |
| `traefik.enabled`             |             | `false`   |
| `traefik.entryPoints.tcp`     |             | `tcp`     |
| `traefik.entryPoints.tcp-tls` |             | `tcp-tls` |
| `traefik.entryPoints.udp`     |             | `udp`     |
| `traefik.entryPoints.udp-tls` |             | `udp-tls` |

### Common Parameters

| Name                                       | Description                                                              | Value                  |
| ------------------------------------------ | ------------------------------------------------------------------------ | ---------------------- |
| `replicaCount`                             |                                                                          | `2`                    |
| `image.repository`                         |                                                                          | `coturn/coturn`        |
| `image.pullPolicy`                         |                                                                          | `Always`               |
| `image.tag`                                | Overrides the image tag whose default is the chart appVersion.           | `""`                   |
| `imagePullSecrets`                         |                                                                          | `[]`                   |
| `nameOverride`                             |                                                                          | `""`                   |
| `fullnameOverride`                         |                                                                          | `""`                   |
| `serviceAccount.create`                    | Specifies whether a service account should be created.                   | `true`                 |
| `serviceAccount.annotations`               | Annotations to add to the service account.                               | `{}`                   |
| `serviceAccount.name`                      | The name of the service account to use. If not set and create is true, a | `""`                   |
| `deploymentAnnotations`                    | Annotations to add to the deployment.                                    | `{}`                   |
| `podAnnotations`                           | Annotations to add to the pod(s).                                        | `{}`                   |
| `defaultLabels`                            | Defines default labels for all created resources.                        | `{}`                   |
| `podSecurityContext`                       |                                                                          | `{}`                   |
| `securityContext.allowPrivilegeEscalation` |                                                                          | `false`                |
| `securityContext.capabilities.add`         |                                                                          | `["NET_BIND_SERVICE"]` |
| `securityContext.capabilities.drop`        |                                                                          | `["ALL"]`              |
| `securityContext.readOnlyRootFilesystem`   |                                                                          | `true`                 |
| `securityContext.runAsNonRoot`             |                                                                          | `true`                 |
| `securityContext.runAsUser`                |                                                                          | `65534`                |
| `service.annotations`                      | Annotations to add to the service.                                       | `{}`                   |
| `service.externalTrafficPolicy`            | Annotations to add to the service.                                       | `nil`                  |
| `service.type`                             |                                                                          | `ClusterIP`            |
| `service.ports.plain`                      |                                                                          | `3478`                 |
| `service.ports.tls`                        |                                                                          | `5349`                 |
| `resources.limits.cpu`                     |                                                                          | `100m`                 |
| `resources.limits.memory`                  |                                                                          | `50Mi`                 |
| `resources.requests.cpu`                   |                                                                          | `100m`                 |
| `resources.requests.memory`                |                                                                          | `50Mi`                 |
| `nodeSelector`                             |                                                                          | `{}`                   |
| `tolerations`                              |                                                                          | `[]`                   |
| `affinity`                                 |                                                                          | `{}`                   |

**This section is generated using metadata from [values.yaml](values.yaml)!**
