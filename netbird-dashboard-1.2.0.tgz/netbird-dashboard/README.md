# netbird-dashboard

Helm chart for [NetBird dashboard](https://github.com/netbirdio/dashboard).

## Parameters

### Authorization

| Name                   | Description                                                                                 | Value                                                  |
| ---------------------- | ------------------------------------------------------------------------------------------- | ------------------------------------------------------ |
| `auth.authority`       | Authority to use for authentication. Must expose a .well-known/oidc-configuration endpoint. | `http://keycloak.localtest.me:9000/realms/helm-charts` |
| `auth.audience`        | Audience of the authentication tokens.                                                      | `netbird-dashboard`                                    |
| `auth.clientID`        | OpenID Connect client ID.                                                                   | `netbird-dashboard`                                    |
| `auth.supportedScopes` | Supported OpenID scopes                                                                     | `openid profile email offline_access api`              |
| `auth.userIDClaim`     |                                                                                             | `sub`                                                  |

### NetBird configuration

| Name                                | Description | Value                   |
| ----------------------------------- | ----------- | ----------------------- |
| `netbird.managementApiEndpoint`     |             | `http://localhost:8081` |
| `netbird.managementGrpcApiEndpoint` |             | `http://localhost:8081` |
| `netbird.disableIPv6`               |             | `true`                  |

### Common configuration

This section contains parameters, that are common for most Helm charts.

| Name                                         | Description                                        | Value                    |
| -------------------------------------------- | -------------------------------------------------- | ------------------------ |
| `replicaCount`                               | Number of replicas to deploy                       | `1`                      |
| `image.repository`                           | image repository                                   | `netbirdio/dashboard`    |
| `image.pullPolicy`                           | image pull policy                                  | `IfNotPresent`           |
| `image.tag`                                  | image tag (immutable tags are recommended)         | `""`                     |
| `imagePullSecrets`                           | image pull secrets                                 | `[]`                     |
| `nameOverride`                               | String to partially override common.names.fullname | `""`                     |
| `fullnameOverride`                           | String to fully override common.names.fullname     | `""`                     |
| `serviceAccount.create`                      | Specifies whether a service account should be      | `true`                   |
| `serviceAccount.annotations`                 | Annotations to add to the service account          | `{}`                     |
| `serviceAccount.name`                        | The name of the service account to use.            | `""`                     |
| `podAnnotations`                             | Annotations for pods                               | `{}`                     |
| `defaultLabels`                              | Defines default labels for all created resources.  | `{}`                     |
| `podSecurityContext`                         |                                                    | `{}`                     |
| `securityContext`                            |                                                    | `{}`                     |
| `service.type`                               |                                                    | `ClusterIP`              |
| `service.port`                               |                                                    | `80`                     |
| `ingress.enabled`                            |                                                    | `false`                  |
| `ingress.className`                          |                                                    | `""`                     |
| `ingress.annotations`                        |                                                    | `{}`                     |
| `ingress.hosts[0].host`                      |                                                    | `chart-example.local`    |
| `ingress.hosts[0].host`                      |                                                    | `chart-example.local`    |
| `ingress.hosts[0].paths[0].path`             |                                                    | `/`                      |
| `ingress.hosts[0].paths[0].pathType`         |                                                    | `ImplementationSpecific` |
| `ingress.tls`                                |                                                    | `[]`                     |
| `resources`                                  |                                                    | `{}`                     |
| `autoscaling.enabled`                        |                                                    | `false`                  |
| `autoscaling.minReplicas`                    |                                                    | `1`                      |
| `autoscaling.maxReplicas`                    |                                                    | `100`                    |
| `autoscaling.targetCPUUtilizationPercentage` |                                                    | `80`                     |
| `autoscaling.targetCPUUtilizationPercentage` |                                                    | `80`                     |
| `nodeSelector`                               |                                                    | `{}`                     |
| `tolerations`                                |                                                    | `[]`                     |
| `affinity`                                   |                                                    | `{}`                     |

**This section is generated using metadata from [values.yaml](values.yaml)!**
