# netbird

Helm chart for [NetBird](https://github.com/netbirdio/netbird) VPN management platform.

## Parameters

### NetBird Parameters

| Name                   | Description                                       | Value                                                  |
| ---------------------- | ------------------------------------------------- | ------------------------------------------------------ |
| `auth.audience`        |                                                   | `account`                                              |
| `auth.authority`       |                                                   | `http://keycloak.localtest.me:9000/realms/helm-charts` |
| `auth.device.provider` |                                                   | `none`                                                 |
| `idp.managerType`      | none, keycloak, or auth0                          | `none`                                                 |
| `stun.uri`             |                                                   | `stun:localhost:3478`                                  |
| `turn.uri`             |                                                   | `turn:localhost:3478`                                  |
| `nameOverride`         |                                                   | `""`                                                   |
| `fullnameOverride`     |                                                   | `""`                                                   |
| `defaultLabels`        | Defines default labels for all created resources. | `{}`                                                   |
| `annotations.grpc`     | Defines ingress annotations for grpc handling     | `{}`                                                   |

### NetBird Management

| Name                                                    | Description                                                    | Value                  |
| ------------------------------------------------------- | -------------------------------------------------------------- | ---------------------- |
| `management.logLevel`                                   |                                                                | `info`                 |
| `management.replicaCount`                               | note that scaling requires a shared filesystem                 | `1`                    |
| `management.image.repository`                           |                                                                | `netbirdio/management` |
| `management.image.pullPolicy`                           |                                                                | `IfNotPresent`         |
| `management.image.tag`                                  | Overrides the image tag whose default is the chart appVersion. | `""`                   |
| `management.imagePullSecrets`                           |                                                                | `[]`                   |
| `management.serviceAccount.create`                      | Specifies whether a service account should be created.         | `true`                 |
| `management.serviceAccount.annotations`                 | Annotations to add to the service account.                     | `{}`                   |
| `management.serviceAccount.name`                        | The name of the service account to use.                        | `""`                   |
| `management.deploymentAnnotations`                      | Annotations to add to the management deployment.               | `{}`                   |
| `management.podAnnotations`                             | Annotations to add to the management pod(s).                   | `{}`                   |
| `management.podSecurityContext`                         |                                                                | `{}`                   |
| `management.securityContext`                            |                                                                | `{}`                   |
| `management.service.type`                               |                                                                | `ClusterIP`            |
| `management.service.port`                               |                                                                | `80`                   |
| `management.metrics.port`                               | path is /metrics                                               | `9090`                 |
| `management.ingress.enabled`                            |                                                                | `false`                |
| `management.ingress.className`                          |                                                                | `""`                   |
| `management.ingress.annotations`                        |                                                                | `{}`                   |
| `management.ingress.hosts.api.host`                     | Hostname to access the API.                                    | `example.com`          |
| `management.ingress.hosts.api.tls`                      | Optional TLS secret information                                | `{}`                   |
| `management.ingress.hosts.grpc.host`                    | Hostname to run GRPC calls againts.                            | `example.com`          |
| `management.ingress.hosts.grpc.tls`                     | Optional TLS secret information                                | `{}`                   |
| `management.resources`                                  |                                                                | `{}`                   |
| `management.autoscaling.enabled`                        |                                                                | `false`                |
| `management.autoscaling.minReplicas`                    |                                                                | `1`                    |
| `management.autoscaling.maxReplicas`                    |                                                                | `100`                  |
| `management.autoscaling.targetCPUUtilizationPercentage` |                                                                | `80`                   |
| `management.nodeSelector`                               |                                                                | `{}`                   |
| `management.tolerations`                                |                                                                | `[]`                   |
| `management.affinity`                                   |                                                                | `{}`                   |
| `management.persistentVolume.enabled`                   |                                                                | `true`                 |
| `management.persistentVolume.accessModes`               |                                                                | `["ReadWriteOnce"]`    |
| `management.persistentVolume.storageClass`              |                                                                | `nil`                  |
| `management.persistentVolume.size`                      |                                                                | `100Mi`                |
| `management.dnsDomain`                                  |                                                                | `netbird.selfhosted`   |
| `management.database`                                   | leave empty to use sqlite                                      | `{}`                   |

### NetBird Signal

| Name                                                | Description                                                    | Value               |
| --------------------------------------------------- | -------------------------------------------------------------- | ------------------- |
| `signal.logLevel`                                   |                                                                | `info`              |
| `signal.uri`                                        |                                                                | `localhost:10000`   |
| `signal.protocol`                                   | grpc, http, https                                              | `https`             |
| `signal.replicaCount`                               |                                                                | `1`                 |
| `signal.image.repository`                           |                                                                | `netbirdio/signal`  |
| `signal.image.pullPolicy`                           |                                                                | `IfNotPresent`      |
| `signal.image.tag`                                  | Overrides the image tag whose default is the chart appVersion. | `""`                |
| `signal.imagePullSecrets`                           |                                                                | `[]`                |
| `signal.serviceAccount.create`                      | Specifies whether a service account should be created.         | `true`              |
| `signal.serviceAccount.annotations`                 | Annotations to add to the service account.                     | `{}`                |
| `signal.serviceAccount.name`                        | The name of the service account to use.                        | `""`                |
| `signal.deploymentAnnotations`                      | Annotations to add to the signal deployment.                   | `{}`                |
| `signal.podAnnotations`                             | Annotations to add to the signal pod(s).                       | `{}`                |
| `signal.podSecurityContext`                         |                                                                | `{}`                |
| `signal.securityContext`                            |                                                                | `{}`                |
| `signal.service.type`                               |                                                                | `ClusterIP`         |
| `signal.service.port`                               |                                                                | `80`                |
| `signal.metrics.port`                               | path is /metrics                                               | `9090`              |
| `signal.ingress.enabled`                            |                                                                | `false`             |
| `signal.ingress.className`                          |                                                                | `""`                |
| `signal.ingress.annotations`                        |                                                                | `{}`                |
| `signal.ingress.hosts.signal.host`                  |                                                                | `example.com`       |
| `signal.ingress.hosts.signal.tls`                   |                                                                | `{}`                |
| `signal.resources`                                  |                                                                | `{}`                |
| `signal.autoscaling.enabled`                        |                                                                | `false`             |
| `signal.autoscaling.minReplicas`                    |                                                                | `1`                 |
| `signal.autoscaling.maxReplicas`                    |                                                                | `100`               |
| `signal.autoscaling.targetCPUUtilizationPercentage` |                                                                | `80`                |
| `signal.nodeSelector`                               |                                                                | `{}`                |
| `signal.tolerations`                                |                                                                | `[]`                |
| `signal.affinity`                                   |                                                                | `{}`                |
| `signal.persistentVolume.enabled`                   |                                                                | `true`              |
| `signal.persistentVolume.accessModes`               |                                                                | `["ReadWriteOnce"]` |
| `signal.persistentVolume.storageClass`              |                                                                | `nil`               |
| `signal.persistentVolume.size`                      |                                                                | `100Mi`             |

### NetBird Relay

| Name                                               | Description                                                    | Value                      |
| -------------------------------------------------- | -------------------------------------------------------------- | -------------------------- |
| `relay.logLevel`                                   |                                                                | `info`                     |
| `relay.domainName`                                 |                                                                | `relay.example.com`        |
| `relay.auth.secret.name`                           | See https://github.com/netbirdio/netbird/releases/tag/v0.29.0  | `netbird-relay-secret`     |
| `relay.auth.secret.key`                            | See https://github.com/netbirdio/netbird/releases/tag/v0.29.0  | `netbird-relay-secret-key` |
| `relay.replicaCount`                               |                                                                | `1`                        |
| `relay.image.repository`                           |                                                                | `netbirdio/relay`          |
| `relay.image.pullPolicy`                           |                                                                | `IfNotPresent`             |
| `relay.image.tag`                                  | Overrides the image tag whose default is the chart appVersion. | `""`                       |
| `relay.serviceAccount.create`                      | Specifies whether a service account should be created.         | `true`                     |
| `relay.serviceAccount.annotations`                 | Annotations to add to the service account.                     | `{}`                       |
| `relay.serviceAccount.name`                        | The name of the service account to use.                        | `""`                       |
| `relay.imagePullSecrets`                           |                                                                | `[]`                       |
| `relay.deploymentAnnotations`                      | Annotations to add to the relay deployment.                    | `{}`                       |
| `relay.podAnnotations`                             | Annotations to add to the relay pod(s).                        | `{}`                       |
| `relay.podSecurityContext`                         |                                                                | `{}`                       |
| `relay.securityContext`                            |                                                                | `{}`                       |
| `relay.service.type`                               |                                                                | `ClusterIP`                |
| `relay.service.port`                               |                                                                | `33080`                    |
| `relay.service.annotations`                        |                                                                | `{}`                       |
| `relay.metrics.port`                               | path is the base path /                                        | `9090`                     |
| `relay.ingress.enabled`                            |                                                                | `false`                    |
| `relay.ingress.className`                          |                                                                | `""`                       |
| `relay.ingress.annotations`                        |                                                                | `{}`                       |
| `relay.ingress.hosts[0].host`                      |                                                                | `example.com`              |
| `relay.ingress.hosts[0].paths[0].path`             |                                                                | `/relay`                   |
| `relay.ingress.hosts[0].paths[0].pathType`         |                                                                | `ImplementationSpecific`   |
| `relay.ingress.tls`                                |                                                                | `[]`                       |
| `relay.resources`                                  |                                                                | `{}`                       |
| `relay.autoscaling.enabled`                        |                                                                | `false`                    |
| `relay.autoscaling.minReplicas`                    |                                                                | `1`                        |
| `relay.autoscaling.maxReplicas`                    |                                                                | `100`                      |
| `relay.autoscaling.targetCPUUtilizationPercentage` |                                                                | `80`                       |
| `relay.nodeSelector`                               |                                                                | `{}`                       |
| `relay.tolerations`                                |                                                                | `[]`                       |
| `relay.affinity`                                   |                                                                | `{}`                       |

**This section is generated using metadata from [values.yaml](values.yaml)!**
